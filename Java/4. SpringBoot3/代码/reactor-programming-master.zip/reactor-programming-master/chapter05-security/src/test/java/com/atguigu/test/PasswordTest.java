package com.atguigu.test;

import org.junit.jupiter.api.Test;

/**
 * @author lfy
 * @Description
 * @create 2023-12-24 22:21
 */
public class PasswordTest {

    @Test
    void test(){

    }
}
